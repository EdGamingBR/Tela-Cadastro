import React from 'react';
import {Text, View,StyleSheet} from 'react-native';
import {RadioButton} from 'react-native-paper'

export default function Escolha (props){
  return(
    <View style={estilos.item}>
    <RadioButton/>
    <Text style={estilos.texto}>{props.texto}</Text>
    </View>
  );
}

const estilos = StyleSheet.create({
item: {
  flexDirection: "row",
  alignItens: "center",
},
texto:{
  margin: 5,
}
});